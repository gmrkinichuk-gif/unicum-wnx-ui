"""The selected vehicle's setup as unicum.gg's `setup` token.

A tank page reads `?setup=<token>` and opens its configurator on that build.
The token is the site's own format (apps/web/src/components/tanks/detail/
specifications/config-url.ts in unicum-gg/unicum.gg): base64url, unpadded,
of a compact query string. What is written here, and where the client keeps
it:

  s  the shell: its index in the gun's shots, for the first shell of the
     ammo layout
  m  gun, turret, engine, chassis, radio intCDs; the turret left empty on a
     vehicle without one, or the site finds no configuration and opens stock
  e  optional device names per slot, empty for a free slot
  r  the role slot's index and category, when that slot is active
  c  consumable names, three slots
  d  directive names
  f  the highest field modification level received
  p  field modification pairs chosen, "name:first" or "name:second"
  u  skill tree steps received, for a tier XI tree instead of f and p
  k  crew skills, "memberIndex:skill"; the site numbers members in the order
     of the vehicle's crew definition with same-role members grouped

And what the page's 3D view shows of the vehicle:

  n  the 2D style worn, by its style id, in the season the garage shows
  w  that season, winter or desert, for a style that differs by season
  t  the 3D style worn, by its models set, which names the site's folder
  x  the marks of excellence on the gun, unless the player hides them

Left out: the crew level (the client no longer has one below 100, which is
the site's default) and the driving mode, which a garage setup does not hold.
A camouflage, paint or decal applied by hand, outside a style, cannot travel:
the site dresses a vehicle in whole styles only, and shows its factory paint
instead. So do the parts of an edited style and a progressive style's level.
Every field is read on its own, and one the client cannot give is skipped: the
site opens on whatever parts of a token it understands.
"""
import base64
import logging

_logger = logging.getLogger('unicum.build')

_PAIR_SIDES = {0: 'first', 1: 'second'}

# c11n_constants.SeasonType values, and how the site names the two it reads.
_WINTER = 1
_SUMMER = 2
_DESERT = 4
_SEASON_NAMES = {_WINTER: 'winter', _DESERT: 'desert'}


def setup_token(vehicle):
    """The token for this gui Vehicle, or None for a stock, empty setup."""
    parts = []
    for key, reader in (('s', _shell), ('m', _modules), ('e', _equipment), ('r', _role_slot),
                        ('c', _consumables), ('d', _directives), ('f', _field_mod_level),
                        ('p', _field_mod_pairs), ('u', _skill_tree), ('k', _crew_skills),
                        ('n', _style_2d), ('w', _style_season), ('t', _style_3d), ('x', _marks)):
        try:
            value = reader(vehicle)
        except Exception:
            _logger.exception('could not read the %s part of the setup', key)
            continue
        if value:
            parts.append('%s=%s' % (key, value))
    if not parts:
        return None
    return base64.urlsafe_b64encode('&'.join(parts)).rstrip('=')


def _csv(values):
    return ','.join('' if value is None else str(value) for value in values)


def _shell(vehicle):
    shells = [shell for shell in vehicle.shells.installed if shell is not None]
    if not shells:
        return None
    shots = [shot.shell.compactDescr for shot in vehicle.descriptor.gun.shots]
    index = shots.index(shells[0].intCD) if shells[0].intCD in shots else 0
    return str(index) if index else None


def _modules(vehicle):
    turret = vehicle.turret.intCD if vehicle.hasTurrets else None
    return _csv([vehicle.gun.intCD, turret, vehicle.engine.intCD, vehicle.chassis.intCD, vehicle.radio.intCD])


def _names(items):
    names = [item.name if item is not None else None for item in items]
    return names if any(names) else None


def _equipment(vehicle):
    names = _names(vehicle.optDevices.installed)
    return _csv(names) if names else None


def _role_slot(vehicle):
    slot_type = vehicle.optDevices.dynSlotType
    if slot_type is None or not vehicle.isRoleSlotActive:
        return None
    categories = list(slot_type.categories)
    return '%d:%s' % (vehicle.optDevices.dynSlotTypeIdx, categories[0]) if categories else None


def _consumables(vehicle):
    names = _names(list(vehicle.consumables.installed)[:3])
    return _csv(names) if names else None


def _directives(vehicle):
    return ','.join(item.name for item in vehicle.battleBoosters.installed if item is not None)


def _received_steps(vehicle):
    progression = vehicle.postProgression
    if progression is None or not progression.isExists():
        return progression, []
    return progression, [step for step in progression.iterUnorderedSteps() if step.isReceived()]


def _field_mod_level(vehicle):
    progression, steps = _received_steps(vehicle)
    if not steps or progression.isVehSkillTree():
        return None
    return str(max(step.getLevel() for step in steps))


def _field_mod_pairs(vehicle):
    progression, steps = _received_steps(vehicle)
    if not steps or progression.isVehSkillTree():
        return None
    pairs = []
    for step in steps:
        action = step.action
        if action.isMultiAction() and action.isPurchased():
            side = _PAIR_SIDES.get(action.getPurchasedIdx())
            if side:
                pairs.append('%s:%s' % (action.getTechName(), side))
    return ','.join(pairs)


def _skill_tree(vehicle):
    progression, steps = _received_steps(vehicle)
    if not steps or not progression.isVehSkillTree():
        return None
    return ','.join(str(step.stepID) for step in steps)


def active_season(vehicle):
    """The season the garage dresses this vehicle in, as the hangar picks it."""
    from gui import g_tankActiveCamouflage
    return g_tankActiveCamouflage.get(vehicle.intCD, vehicle.getAnyOutfitSeason())


def fleet_marks(items=None):
    """{intCD: (marks, percent)} for every tank the account has ever PLAYED.

    Not the garage: the account dossier. The two are different sets and the
    difference is the point -- a tank that was sold leaves the inventory and
    keeps its record, which is why the game's own Service Record still lists it
    with its marks while the hangar no longer shows it. Reading the inventory
    meant answering "nothing" for every one of those, and on one real account
    that was sixty tanks out of a hundred and seventy-nine.

    `a15x15Cut` is the list the Service Record itself walks, so this covers
    exactly what a player sees there. Random battles only, which is right: marks
    are earned in random battles and nowhere else.

    Entirely local and synchronous. The dossier cache is synced once at login
    and sits on disk; nothing here asks the server for anything, which is what
    makes it safe to run on the thread that draws the garage.
    """
    from dossiers2.ui.achievements import MARK_ON_GUN_RECORD
    if items is None:
        from helpers import dependency
        from skeletons.gui.shared import IItemsCache
        items = dependency.instance(IItemsCache).items
    out = {}
    try:
        played = items.getAccountDossier().getRandomStats().getVehicles()
    except Exception:
        _logger.exception('could not read the account dossier')
        return out
    for intCD in played:
        try:
            dossier = items.getVehicleDossier(intCD)
            if not dossier:
                continue
            achievement = dossier.getRandomStats().getAchievement(MARK_ON_GUN_RECORD)
            if achievement is None:
                continue
            marks = achievement.getValue() or 0
            rating = achievement.getDamageRating()
        except Exception:
            # One unreadable dossier is not worth the fleet, and a client
            # patch is exactly how one appears.
            continue
        if marks or rating:
            out[intCD] = (marks, float(rating) if rating is not None else None)
    return out


def mark_record(vehicle, items=None):
    """(marks, percent) of excellence for a vehicle, or (0, None) for neither.

    The REAL progress, which is a different question from what the garage
    paints. `marks_on_gun` below answers "what should this gun look like" and
    so honours the player's own `showMarksOnGun` setting; a figure reported as
    data must not, or a player who turned the decoration off would appear to
    have lost every mark they own.

    The percent comes back from the client ALREADY as a percent, 95.07 and not
    9507: the dossier stores hundredths as a whole number, but `getDamageRating`
    is the accessor that divides them, and dividing again turned a gun at 95 %
    into one at 0.95 %. Measured on a live carousel of 209 tanks, which is the
    only way this was ever going to be settled. Finer than the battle results,
    which round to the percent, and this is the value the fleet is measured by.

    Nothing leaves the client for this: the dossier is already in the cache the
    garage drew itself from. `items` is that cache, handed down by a caller
    sweeping a carousel, because resolving the service once per vehicle over a
    few hundred of them is a few hundred lookups nobody asked for.
    """
    from dossiers2.ui.achievements import MARK_ON_GUN_RECORD
    if items is None:
        from helpers import dependency
        from skeletons.gui.shared import IItemsCache
        items = dependency.instance(IItemsCache).items
    dossier = items.getVehicleDossier(vehicle.intCD)
    if not dossier:
        return 0, None
    # Two blocks carry the record, and which one answers is a question about
    # this client rather than about this tank: `getRandomStats` is the one the
    # garage itself reads for the decoration, `getTotalStats` is the one the
    # decompiled sources name. Ask both rather than pick, because a silent
    # `None` from the wrong one looks exactly like a gun with no marks.
    achievement = None
    for block in ('getRandomStats', 'getTotalStats'):
        reader = getattr(dossier, block, None)
        if reader is None:
            continue
        try:
            found = reader().getAchievement(MARK_ON_GUN_RECORD)
        except Exception:
            continue
        if found is not None:
            achievement = found
            break
    if achievement is None:
        return 0, None
    marks = achievement.getValue() or 0
    try:
        rating = achievement.getDamageRating()
    except Exception:
        _logger.exception('no damage rating for %s', vehicle.intCD)
        return marks, None
    # None and not zero when it is missing: a tank really sitting at 0 % and a
    # tank we could not read are different facts, and a zero written for the
    # second would show as a gun that lost its progress.
    return marks, (float(rating) if rating is not None else None)


def marks_on_gun(vehicle):
    """The marks of excellence the garage paints on the gun: 0 when hidden."""
    from dossiers2.ui.achievements import MARK_ON_GUN_RECORD
    from helpers import dependency
    from skeletons.account_helpers.settings_core import ISettingsCore
    from skeletons.gui.shared import IItemsCache
    if not dependency.instance(ISettingsCore).getSetting('showMarksOnGun'):
        return 0
    dossier = dependency.instance(IItemsCache).items.getVehicleDossier(vehicle.intCD)
    achievement = dossier.getRandomStats().getAchievement(MARK_ON_GUN_RECORD) if dossier else None
    return achievement.getValue() if achievement else 0


def _worn_style(vehicle):
    """(outfit, style, season) of what the garage shows, or Nones."""
    season = active_season(vehicle)
    outfit = vehicle.getOutfit(season)
    style = outfit.style if outfit is not None else None
    return outfit, style, season


def _style_2d(vehicle):
    outfit, style, _ = _worn_style(vehicle)
    # isHiddenInUI is a method on the client's StyleItem: the bound method
    # itself is always true, which hid every style.
    if style is None or style.is3D or 'c11n2D' not in style.tags or style.isHiddenInUI():
        return None
    return str(outfit.id)


def _style_season(vehicle):
    _, style, season = _worn_style(vehicle)
    if style is None or style.is3D or season not in _SEASON_NAMES:
        return None
    # A style with one outfit for every season holds the same object for each.
    if style.outfits.get(season) is style.outfits.get(_SUMMER):
        return None
    return _SEASON_NAMES[season]


def _style_3d(vehicle):
    _, style, _ = _worn_style(vehicle)
    return style.modelsSet if style is not None and style.is3D and style.modelsSet else None


def _marks(vehicle):
    count = marks_on_gun(vehicle)
    return str(count) if count > 0 else None


def crew_member_indexes(crew_roles):
    """Slot index -> the site's member index.

    The site reads a vehicle's crew definition with same-role members
    grouped under their first role, in order of first appearance: a radioman
    listed apart from the other comes right after it. Only two vehicles have
    such a split, but for them the plain slot order is off by one.
    """
    order = []
    for slot, roles in enumerate(crew_roles):
        first = roles[0]
        group = next((g for g in order if g[0] == first), None)
        if group is None:
            order.append((first, [slot]))
        else:
            group[1].append(slot)
    indexes = {}
    for _, slots in order:
        for slot in slots:
            indexes[slot] = len(indexes)
    return indexes


def _crew_skills(vehicle):
    indexes = crew_member_indexes(vehicle.descriptor.type.crewRoles)
    skills = []
    for slot, tankman in vehicle.crew:
        if tankman is None or slot not in indexes:
            continue
        names = [skill.name for skill in tankman.skills]
        for bonus in tankman.bonusSkills.values():
            names.extend(skill.name for skill in bonus if skill is not None)
        for name in names:
            entry = '%d:%s' % (indexes[slot], name)
            if entry not in skills:
                skills.append(entry)
    return ','.join(skills)


# What the build is, in the client's own words rather than a token: the parts
# that carry a name, in the order they are worth reading. The modules are left
# out, being intCDs, and the cosmetics with them: neither says anything about
# how the vehicle plays.
_IN_WORDS = (
    ('equipment', _equipment),
    ('role slot', _role_slot),
    ('consumables', _consumables),
    ('directives', _directives),
    ('field modifications', _field_mod_pairs),
    ('crew skills', _crew_skills),
)


def plain_setup(vehicle):
    """The build written out, for a reader that cannot open the page carrying it.

    The site's own token is base64url and has to be decoded before it says
    anything; these are the same choices as words, which an assistant reads
    without being asked to. Every name is the client's, which is what the
    game's own wiki and every guide call them.
    """
    said = []
    for label, reader in _IN_WORDS:
        try:
            value = reader(vehicle)
        except Exception:
            _logger.exception('could not read the %s of the build', label)
            continue
        # The token keeps an empty slot as an empty field, since the position
        # of the next one depends on it. Written out, a hole says nothing.
        worn = ', '.join(part for part in str(value or '').split(',') if part)
        if worn:
            said.append('- %s: %s' % (label, worn))
    return '\n'.join(said) or None
