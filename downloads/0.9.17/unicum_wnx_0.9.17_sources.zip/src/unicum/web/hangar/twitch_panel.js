// The player's Twitch chat in the garage: messages as they come, and a field
// to write in the chat.
//
// Run by the loader (res/gui/gameface/mods/unicum/TankButton/TankButton.js)
// beside the tank menu, as the body of a function of `api` = { model, media,
// playSound, report }, and run again whenever this file changes: it returns
// { stop() }, which takes back everything it added. Python
// (src/unicum/twitch_panel.py) puts the chat in the model's `twitch` string
// as JSON; the panel reads it on a timer, since the model observer has no way
// to unsubscribe and every reload would stack one more callback. What the
// player does goes back through the model's onItemClick: twitchSend,
// twitchConnect, twitchCollapse, twitchMove ("left,top" in rem, or "" for the
// panel's own place under the mission widgets) and twitchResize
// ("width,height" in rem, or "" for the stylesheet's size).
//
// The same code runs in the unicum.gg Twitch window (api.windowed), which
// stands in for the garage where the hangar is gone, on the battle queue
// screen (src/unicum/twitch_window.py). There the window is the panel's
// place: the panel sits in its corner at the size Python gives it, and
// keeps quiet about where it is, which is the garage panel's to say. A press
// on its header or its corner only tells Python (twitchWindowDrag,
// twitchWindowResize), which moves or sizes the window itself as the mouse
// goes: the page cannot follow a mouse that leaves it.
//
// Gameface: a plain focused <input type="text"> is what the game's own chats
// use, and the hangar's hotkeys skip themselves while one has focus. Images
// are sized divs with a background (an <img> ignores its size). Scrolling is
// done by hand on an overflow: hidden list, as the game does.

const { model, report } = api;
const windowed = Boolean(api.windowed);
// Replaced by Python with data URIs of web/hangar/panel_icons/*.png.
const PANEL_ICONS = __PANEL_ICONS__;

const state = {
    alive: true, json: null, data: null, stuckToBottom: true, drag: null, resize: null,
    // The key code that types "a" on this keyboard, and the last key typed.
    selectAllKey: 65, lastKey: 0,
    // What the hangar lends, each read once and kept: the layer that draws its
    // cards, and the column they line up in (`syncDecor`, `column`).
    decor: null, column: null,
};

// Pixels to the rem the hangar lays out in; 1 when the view does not say.
const toRem = (px) => (typeof viewEnv !== "undefined" && viewEnv.pxToRem ? viewEnv.pxToRem(px) : px);
const DRAG_THRESHOLD = 4;

// The chat text size the player chose, as a class on the root. A class
// rather than a property set on the node, because renderFrame rewrites
// className outright and anything put on the node outside the render is
// dropped by the next one, which is what left the panel with no edge
// before. `normal` adds nothing and the sheet's own size stands.
const TEXT_CLASSES = {
    small: " UnicumTwitchPanel__text_small",
    large: " UnicumTwitchPanel__text_large",
    larger: " UnicumTwitchPanel__text_larger",
};

const root = document.createElement("div");
// Plain until the hangar lends its decor, and plain for good in the battle
// queue window, where there is no hangar to lend it (twitch_panel.css).
root.className = "UnicumTwitchPanel UnicumTwitchPanel__plain";
// Hidden until Python has said anything: a button made before this panel
// existed has no `twitch` property at all.
root.style.display = "none";

const header = document.createElement("div");
header.className = "UnicumTwitchPanel_header";
const logo = document.createElement("div");
logo.className = "UnicumTwitchPanel_logo";
const heading = document.createElement("div");
heading.className = "UnicumTwitchPanel_heading";
const title = document.createElement("div");
title.className = "UnicumTwitchPanel_title";
// Only without a channel, where the panel folds into a card like the account's.
const subtitle = document.createElement("div");
subtitle.className = "UnicumTwitchPanel_subtitle";
subtitle.textContent = "Link your Twitch to see your chat here";
heading.appendChild(title);
heading.appendChild(subtitle);
const cardConnect = document.createElement("div");
cardConnect.className = "UnicumTwitchPanel_cardConnect";
cardConnect.textContent = "Connect";
// Under the header, across the card, as on the account card.
const reset = document.createElement("div");
reset.className = "UnicumTwitchPanel_reset";
// An image: the hangar's font has no arrow glyphs, so a "↺" drew nothing.
reset.style.backgroundImage = `url(${PANEL_ICONS.reset})`;
const toggle = document.createElement("div");
toggle.className = "UnicumTwitchPanel_toggle";
const close = document.createElement("div");
close.className = "UnicumTwitchPanel_close";
close.style.backgroundImage = `url(${PANEL_ICONS.close})`;
header.appendChild(logo);
header.appendChild(heading);
header.appendChild(reset);
header.appendChild(toggle);
header.appendChild(close);

const list = document.createElement("div");
list.className = "UnicumTwitchPanel_list";
const lines = document.createElement("div");
lines.className = "UnicumTwitchPanel_lines";
// A chat nobody has written in yet looks exactly like a panel that failed to
// load, so the list says which it is until the first message arrives.
const empty = document.createElement("div");
empty.className = "UnicumTwitchPanel_empty";
const emptyTitle = document.createElement("div");
emptyTitle.className = "UnicumTwitchPanel_emptyTitle";
const emptyText = document.createElement("div");
emptyText.className = "UnicumTwitchPanel_emptyText";
empty.appendChild(emptyTitle);
empty.appendChild(emptyText);
list.appendChild(lines);
list.appendChild(empty);

const footer = document.createElement("div");
footer.className = "UnicumTwitchPanel_footer";
const input = document.createElement("input");
input.type = "text";
input.maxLength = 500;
input.className = "UnicumTwitchPanel_input";
input.placeholder = "Send a message";
const connect = document.createElement("div");
connect.className = "UnicumTwitchPanel_connect";
connect.textContent = "Connect to write in your chat";
footer.appendChild(input);
footer.appendChild(connect);

// Bottom right, as every resizable window in the game: drag to size the panel.
const grip = document.createElement("div");
grip.className = "UnicumTwitchPanel_grip";

// The edge, where there is nobody to borrow one from. In the garage the panel
// takes the hangar's own noise layer by class (`syncDecor`); the window has no
// card to read a class off and no hangar stylesheet to hold the rule anyway,
// so it grafts the layer itself and hands it the client's texture, carried
// with the panel's icons as a data URI. The stylesheet says what is in it.
if (windowed && PANEL_ICONS.card_noise) {
    const noise = document.createElement("div");
    noise.className = "UnicumTwitchPanel_noise";
    noise.style.borderImage = `url(${PANEL_ICONS.card_noise}) 1/1rem repeat`;
    root.appendChild(noise);
}
root.appendChild(header);
root.appendChild(cardConnect);
root.appendChild(list);
root.appendChild(footer);
root.appendChild(grip);
document.body.appendChild(root);

function send(item, text) {
    if (model.model) {
        model.model.onItemClick({ item, text: text === undefined ? "" : String(text) });
    }
}

function stop(event) {
    event.stopPropagation();
}

function onHeaderMouseDown(event) {
    if (event.button !== undefined && event.button !== 0) {
        return;
    }
    event.stopPropagation();
    if (windowed) {
        // Python moves the window, or folds the panel for a click.
        send("twitchWindowDrag");
        return;
    }
    const rect = root.getBoundingClientRect();
    state.drag = { x: event.clientX, y: event.clientY, left: rect.left, top: rect.top, moved: false };
    document.addEventListener("mousemove", onDragMove);
    document.addEventListener("mouseup", onDragEnd);
}

function onDragMove(event) {
    const drag = state.drag;
    if (!drag) {
        return;
    }
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    if (!drag.moved && Math.abs(dx) < DRAG_THRESHOLD && Math.abs(dy) < DRAG_THRESHOLD) {
        return;
    }
    if (!drag.moved) {
        drag.moved = true;
        root.classList.add("UnicumTwitchPanel__dragging");
        // On the whole page too: the pointer leaves the header at once, and
        // every element it crosses would otherwise put its own cursor back.
        document.body.classList.add("UnicumPanelDragging");
    }
    const rect = root.getBoundingClientRect();
    const left = Math.min(Math.max(0, drag.left + dx), Math.max(0, window.innerWidth - rect.width));
    const top = Math.min(Math.max(0, drag.top + dy), Math.max(0, window.innerHeight - rect.height));
    place([toRem(left), toRem(top)]);
    event.stopPropagation();
}

function onDragEnd(event) {
    const drag = state.drag;
    state.drag = null;
    document.removeEventListener("mousemove", onDragMove);
    document.removeEventListener("mouseup", onDragEnd);
    if (!drag) {
        return;
    }
    event.stopPropagation();
    if (drag.moved) {
        root.classList.remove("UnicumTwitchPanel__dragging");
        document.body.classList.remove("UnicumPanelDragging");
        const rect = root.getBoundingClientRect();
        send("twitchMove", `${Math.round(toRem(rect.left))},${Math.round(toRem(rect.top))}`);
    } else if (state.data) {
        state.data.collapsed = !state.data.collapsed;
        renderFrame(state.data);
        send("twitchCollapse", state.data.collapsed ? "1" : "0");
    }
}

function onGripMouseDown(event) {
    if (event.button !== undefined && event.button !== 0) {
        return;
    }
    event.stopPropagation();
    if (windowed) {
        send("twitchWindowResize");
        return;
    }
    const rect = root.getBoundingClientRect();
    state.resize = { x: event.clientX, y: event.clientY,
                     width: toRem(rect.width), height: toRem(rect.height),
                     left: rect.left, top: rect.top };
    document.body.classList.add("UnicumPanelResizing");
    document.addEventListener("mousemove", onResizeMove);
    document.addEventListener("mouseup", onResizeEnd);
}

function onResizeMove(event) {
    const resize = state.resize;
    if (!resize) {
        return;
    }
    event.stopPropagation();
    // Never past the screen: the panel is dragged by a corner that would
    // otherwise end up somewhere the player cannot reach it again.
    const room = { width: toRem(window.innerWidth - resize.left), height: toRem(window.innerHeight - resize.top) };
    const width = Math.round(Math.min(Math.max(resize.width + toRem(event.clientX - resize.x), MIN_WIDTH),
                                      Math.min(MAX_WIDTH, room.width)));
    const height = Math.round(Math.min(Math.max(resize.height + toRem(event.clientY - resize.y), MIN_HEIGHT),
                                       Math.min(MAX_HEIGHT, room.height)));
    resize.wanted = [width, height];
    size(resize.wanted);
    if (state.stuckToBottom) {
        list.scrollTop = Math.max(0, lines.offsetHeight - list.clientHeight);
    }
}

function onResizeEnd(event) {
    const resize = state.resize;
    state.resize = null;
    document.body.classList.remove("UnicumPanelResizing");
    document.removeEventListener("mousemove", onResizeMove);
    document.removeEventListener("mouseup", onResizeEnd);
    if (!resize) {
        return;
    }
    event.stopPropagation();
    if (resize.wanted) {
        if (state.data) {
            state.data.size = resize.wanted;
        }
        send("twitchResize", `${resize.wanted[0]},${resize.wanted[1]}`);
    }
}

// Learns the layout: the key last pressed, and the letter it put in the field.
function onInput() {
    const at = input.selectionStart;
    const typed = at > 0 ? input.value.charAt(at - 1).toLowerCase() : "";
    if (typed === "a" && state.lastKey) {
        state.selectAllKey = state.lastKey;
    }
}

function onResetMouseDown(event) {
    event.stopPropagation();
}

function onResetClick(event) {
    event.stopPropagation();
    if (state.data) {
        state.data.position = null;
        state.data.size = null;
        renderFrame(state.data);
    }
    send("twitchMove", "");
    send("twitchResize", "");
}

// Turns the panel off in the settings; the settings window turns it back on.
function onCloseClick(event) {
    event.stopPropagation();
    root.style.display = "none";
    send("twitchClose");
}

// The gap the hangar leaves between two mission cards.
const CARD_GAP = 8;
// The panel's parts, in rem, as the stylesheet draws them: the list is what is
// left of the panel once the header, the footer and the two borders are taken.
const HEADER_HEIGHT = 34;
const FOOTER_HEIGHT = 40;
const BORDERS = 2;
const LIST_PADDING = 12;
// Small enough to tuck away, large enough for a name and a line of chat. The
// same bounds as the settings' (src/unicum/settings.py), which has the last word.
const MIN_WIDTH = 220;
const MIN_HEIGHT = 120;
const MAX_WIDTH = 1600;
const MAX_HEIGHT = 1200;
// The stylesheet's own size, which the panel keeps until the player drags it.
const DEFAULT_WIDTH = 322;
const DEFAULT_HEIGHT = 220;
// And its own place: its right and top offsets.
const OWN_RIGHT = 46;
const OWN_TOP = 890;

// The hangar's mission cards, which this panel hangs under: the column they
// line up in gives it its width and its gap to the screen's edge, and one of
// them lends the layer that draws it.
const MISSION_CARDS = '[class*="QuestCard_base"], [class*="PersonalMissionCard_base"]';

// One of those cards, or null. Unlike the panel's own top, which follows the
// account card and so has to ignore the cards the hangar keeps laid out but
// transparent, a card on its way out carries the same column and the same
// class names as one on show, so any of them will do here.
function missionCard() {
    for (const card of document.querySelectorAll(MISSION_CARDS)) {
        if (card.getBoundingClientRect().width > 0) {
            return card;
        }
    }
    return null;
}

// The whole class name of `node` that `exact` matches, or null.
function matching(node, exact) {
    for (const name of String(node.className || "").split(/\s+/)) {
        if (exact.test(name)) {
            return name;
        }
    }
    return null;
}

// The width of the hangar's mission column and its gap to the right edge, in
// rem. Measured because the hangar gives that column 241rem or 319rem
// depending on the screen, so a width written here would be wrong on one of
// them; kept until the screen changes size.
function column() {
    if (windowed) {
        return null;
    }
    if (state.column && state.column.screen === window.innerWidth) {
        return state.column;
    }
    const card = missionCard();
    if (!card) {
        return null;
    }
    const rect = card.getBoundingClientRect();
    state.column = {
        screen: window.innerWidth,
        width: Math.round(toRem(rect.width)),
        right: Math.round(toRem(window.innerWidth - rect.right)),
    };
    return state.column;
}

// The layer that draws a hangar card at rest: a border-image of the ui_kit's
// noise, borrowed by class because the hash in that name changes with every
// client build. account_card.js borrows the same and says more about why.
function syncDecor() {
    if (state.decor || windowed) {
        return;
    }
    const card = missionCard();
    if (!card) {
        return;
    }
    const base = matching(card, /^Card_[0-9a-f]+$/);
    const node = card.querySelector('[class*="Card_borderHelper_"]');
    const noise = node ? matching(node, /^Card_borderHelper_[0-9a-f]+$/) : null;
    if (!base || !noise) {
        return;
    }
    state.decor = { base: base, noise: noise };
    const layer = document.createElement("div");
    layer.className = noise;
    root.insertBefore(layer, root.firstChild);
    // The noise is styled only as a child of the card's own class.
    root.classList.add(base);
    root.classList.remove("UnicumTwitchPanel__plain");
    report(`twitch panel: drawn by the hangar (${base})`);
}

// The panel at the size the player dragged it to, or the hangar's column.
function size(wanted) {
    const collapsed = root.classList.contains("UnicumTwitchPanel__collapsed");
    const compact = root.classList.contains("UnicumTwitchPanel__compact");
    const own = column();
    root.style.width = wanted ? `${wanted[0]}rem` : (own ? `${own.width}rem` : "");
    // Folded or without a chat, the height is the class's; the width is kept.
    root.style.height = wanted && !collapsed && !compact ? `${wanted[1]}rem` : "";
    const height = wanted ? wanted[1] - HEADER_HEIGHT - FOOTER_HEIGHT - BORDERS : 0;
    list.style.height = height > 0 ? `${height}rem` : "";
    empty.style.height = height > 0 ? `${height - LIST_PADDING}rem` : "";
}

// How far down the hangar's widget column goes: the tank carousel's top edge,
// the page's bottom where a screen has no carousel. The mission cards and the
// account card stop well short of it, but the panel hangs under them and, with
// the account card's Connect adding a row, it ended up flush against the
// carousel.
function floorOf() {
    const carousel = document.querySelector('[class*="Page_carousel"]');
    if (carousel) {
        const rect = carousel.getBoundingClientRect();
        if (rect.height > 0 && rect.top > 0) {
            return rect.top;
        }
    }
    const page = document.querySelector('[class*="HangarScreen_hangarPage"]');
    if (page) {
        const rect = page.getBoundingClientRect();
        if (rect.bottom > 0) {
            return rect.bottom;
        }
    }
    return window.innerHeight;
}

// The panel shortened to what is left above that floor, when what it is asking
// for does not fit. Shorter beats hidden behind the carousel; the player's own
// size is left in the settings, so a screen with room enough shows it again.
function fit() {
    if (root.classList.contains("UnicumTwitchPanel__collapsed")
            || root.classList.contains("UnicumTwitchPanel__compact")) {
        return;
    }
    const wanted = state.data && state.data.size;
    const room = Math.round(toRem(floorOf() - root.getBoundingClientRect().top)) - CARD_GAP;
    const height = wanted ? wanted[1] : DEFAULT_HEIGHT;
    if (room < height) {
        const own = column();
        size([wanted ? wanted[0] : (own ? own.width : DEFAULT_WIDTH), Math.max(MIN_HEIGHT, room)]);
    } else {
        size(wanted);
    }
}

// Where the player put the panel, or its own place: right under the account
// card when it is on screen (its height changes with the link), else the
// stylesheet's.
function place(position) {
    if (windowed) {
        root.style.left = "0";
        root.style.top = "0";
        root.style.right = "auto";
        return;
    }
    if (position) {
        root.style.left = `${position[0]}rem`;
        root.style.top = `${position[1]}rem`;
        root.style.right = "auto";
        return;
    }
    root.style.left = "";
    // On the mission column's own right edge, which the account card above
    // shares: the three of them read as one column or as none.
    const own = column();
    root.style.right = own ? `${own.right}rem` : "";
    const card = document.querySelector(".UnicumAccountCard");
    const rect = card && card.style.display !== "none" ? card.getBoundingClientRect() : null;
    root.style.top = rect && rect.height > 0 ? `${Math.round(toRem(rect.bottom)) + CARD_GAP}rem` : "";
    if (!state.resize) {
        fit();
    }
}

function onConnectClick(event) {
    event.stopPropagation();
    send("twitchConnect");
}

function handled(event) {
    event.stopPropagation();
    event.preventDefault();
    if (typeof viewEnv !== "undefined" && viewEnv.setEventHandled) {
        viewEnv.setEventHandled();
    }
}

function onKeyDown(event) {
    if (!event.ctrlKey && !event.metaKey && !event.altKey) {
        state.lastKey = event.keyCode;
    }
    if (event.key === "Enter" || event.keyCode === 13) {
        const text = input.value.trim();
        if (text) {
            send("twitchSend", text);
            input.value = "";
            state.stuckToBottom = true;
        }
        handled(event);
    } else if (event.key === "Escape" || event.keyCode === 27) {
        input.blur();
        handled(event);
    } else if ((event.ctrlKey || event.metaKey) && event.keyCode === state.selectAllKey) {
        // Gameface's input has no select-all of its own. Its key events name
        // a key by its QWERTY place whatever the layout, so the key that types
        // "a" is learnt from typing (onInput): Q on AZERTY, A until then.
        try {
            input.select();
        } catch (error) {
            report(`twitch panel: select failed: ${error}`);
        }
        try {
            input.setSelectionRange(0, input.value.length);
        } catch (error) {
            report(`twitch panel: setSelectionRange failed: ${error}`);
        }
        handled(event);
    } else {
        event.stopPropagation();
    }
}

function onWheel(event) {
    event.stopPropagation();
    event.preventDefault();
    const max = Math.max(0, lines.offsetHeight - list.clientHeight);
    list.scrollTop = Math.min(max, Math.max(0, list.scrollTop + event.deltaY));
    state.stuckToBottom = list.scrollTop >= max - 4;
}

input.addEventListener("input", onInput);
header.addEventListener("mousedown", onHeaderMouseDown);
reset.addEventListener("mousedown", onResetMouseDown);
reset.addEventListener("click", onResetClick);
close.addEventListener("mousedown", onResetMouseDown);
close.addEventListener("click", onCloseClick);
grip.addEventListener("mousedown", onGripMouseDown);
connect.addEventListener("click", onConnectClick);
cardConnect.addEventListener("mousedown", onResetMouseDown);
cardConnect.addEventListener("click", onConnectClick);
input.addEventListener("keydown", onKeyDown);
input.addEventListener("keyup", stop);
root.addEventListener("mousedown", stop);
root.addEventListener("wheel", onWheel);

function line(message) {
    const row = document.createElement("div");
    row.className = "UnicumTwitchPanel_line";
    for (const badge of message.badges || []) {
        const image = document.createElement("div");
        image.className = "UnicumTwitchPanel_badge";
        image.style.backgroundImage = `url(${badge})`;
        row.appendChild(image);
    }
    const name = document.createElement("span");
    name.className = "UnicumTwitchPanel_name";
    name.textContent = `${message.name}:`;
    if (message.color) {
        name.style.color = message.color;
    }
    const text = document.createElement("span");
    text.className = "UnicumTwitchPanel_text";
    text.textContent = message.text;
    row.appendChild(name);
    row.appendChild(text);
    return row;
}

// The panel's frame alone: shown, folded, where. What a click changes, drawn
// at once rather than after the round trip through Python.
function renderFrame(data) {
    // Covered by the Twitch window, which draws the same panel on top: two
    // veils would show darker than one (src/unicum/twitch_window.py).
    root.style.display = data.shown ? "" : "none";
    // Hidden but laid out, so it still says where it is.
    root.style.visibility = data.covered ? "hidden" : "";
    // No channel, no chat to show: a card with its Connect, as the account's.
    const compact = !data.channel;
    root.className = "UnicumTwitchPanel" + (compact ? " UnicumTwitchPanel__compact" : "") +
        (data.collapsed && !compact ? " UnicumTwitchPanel__collapsed" : "") +
        (windowed ? " UnicumTwitchPanel__windowed" : "") +
        // What draws the panel's edge, and it has to be composed here rather
        // than only added when it is found: this line rewrites className
        // outright, so a class merely added to the node is dropped by the
        // next render, and the next chat message to arrive is a render.
        // account_card.js composes its borrowed class the same way.
        //
        // The hangar's own class, which its noise layer is styled under. The
        // window needs none: it carries its own layer, grafted above. What is
        // left is the garage before the hangar has lent anything, where the
        // fallback stands in for the moment it takes.
        (state.decor ? " " + state.decor.base : (windowed ? "" : " UnicumTwitchPanel__plain")) +
        (TEXT_CLASSES[data.textSize] || "") +
        (state.drag && state.drag.moved ? " UnicumTwitchPanel__dragging" : "");
    if (!state.resize) {
        size(data.size);
    }
    if (!state.drag) {
        place(data.position);
    }
    // The arrow puts the panel back where and as the stylesheet has it.
    // In the window, position and size are the window's: `moved` says
    // whether the player's own are set.
    reset.style.display = (windowed ? data.moved : data.position || data.size) ? "" : "none";
    logo.style.backgroundImage = data.icon ? `url(${data.icon})` : "";
    title.textContent = data.channel ? `Twitch · ${data.channel}` : "Twitch";
    toggle.style.backgroundImage = `url(${data.collapsed ? PANEL_ICONS.expand : PANEL_ICONS.collapse})`;
    input.style.display = data.linked ? "" : "none";
    connect.style.display = data.linked ? "none" : "";
}

function render(data) {
    renderFrame(data);
    while (lines.firstChild) {
        lines.removeChild(lines.firstChild);
    }
    const messages = data.messages || [];
    for (const message of messages) {
        lines.appendChild(line(message));
    }
    // Twitch sends no history, so a chat that is quiet stays blank however
    // long it has been joined: say so rather than leave an empty box.
    empty.style.display = messages.length ? "none" : "";
    emptyTitle.textContent = data.joined ? "No messages yet" : "Connecting to the chat";
    emptyText.textContent = data.joined
        ? `What is written in ${data.channel}'s chat from now on shows up here.`
        : `Joining ${data.channel}'s chat on Twitch.`;
    if (state.stuckToBottom) {
        list.scrollTop = Math.max(0, lines.offsetHeight - list.clientHeight);
    }
}

function poll() {
    if (!state.alive) {
        return;
    }
    const current = model.model;
    const json = current && current.twitch;
    if (!json || json === state.json) {
        // The account card can change height on its own: follow it.
        if (state.data && !state.data.position && !state.drag) {
            place(null);
        }
        return;
    }
    state.json = json;
    try {
        state.data = JSON.parse(json);
        render(state.data);
        // A second pass once the new lines have a height.
        setTimeout(() => state.alive && state.stuckToBottom && render(state.data), 50);
    } catch (error) {
        report(`twitch panel: render failed: ${error}`);
    }
}

// Where the panel is on screen, in the hangar's pixels, and its size in rem,
// its height unfolded even while it is folded, then where it would go
// without the player's place, in pixels: the battle queue screen, which
// replaces the hangar and this panel with it, opens the Twitch window at the
// same place and size, and puts it back there when reset
// (src/unicum/twitch_window.py). Sent when it changes, and again now and
// then, since a reload of the mod forgets it.
const RECT_RESEND = 20;
let rectSent = "";
let rectTicks = 0;
let openHeight = 0;

// The panel's own top left corner, in pixels, as place(null) and the
// stylesheet put it: right under the account card when it shows, on the
// mission column's right edge and at its width, or the stylesheet's own two
// when the hangar has no card to measure.
function ownPlace(pxPerRem) {
    const card = document.querySelector(".UnicumAccountCard");
    const cardRect = card && card.style.display !== "none" ? card.getBoundingClientRect() : null;
    const top = cardRect && cardRect.height > 0
        ? (Math.round(toRem(cardRect.bottom)) + CARD_GAP) * pxPerRem
        : OWN_TOP * pxPerRem;
    const own = column() || { right: OWN_RIGHT, width: DEFAULT_WIDTH };
    return [window.innerWidth - (own.right + own.width) * pxPerRem, top];
}

function reportRect() {
    if (windowed || !state.data || root.style.display === "none") {
        return;
    }
    const rect = root.getBoundingClientRect();
    const folded = root.classList.contains("UnicumTwitchPanel__collapsed");
    if (!folded) {
        openHeight = toRem(rect.height);
    }
    const height = openHeight || (state.data.size ? state.data.size[1] : DEFAULT_HEIGHT);
    const own = ownPlace(rect.width / Math.max(1, toRem(rect.width)));
    const text = [rect.left, rect.top, rect.width, rect.height, window.innerWidth, window.innerHeight,
                  folded ? 1 : 0, toRem(rect.width), height, own[0], own[1]]
        .map((value) => Math.round(value)).join(",");
    rectTicks += 1;
    if (text === rectSent && rectTicks < RECT_RESEND) {
        return;
    }
    rectSent = text;
    rectTicks = 0;
    send("twitchRect", text);
}

const timer = setInterval(() => {
    // The hangar's cards can arrive after this script does, and its decor with
    // them: until they do the panel stays plain.
    syncDecor();
    poll();
    reportRect();
}, 250);
poll();

return {
    stop() {
        state.alive = false;
        clearInterval(timer);
        // A reload mid-drag must not leave the page stuck on a drag cursor.
        document.body.classList.remove("UnicumPanelDragging");
        document.body.classList.remove("UnicumPanelResizing");
        input.removeEventListener("input", onInput);
        header.removeEventListener("mousedown", onHeaderMouseDown);
        reset.removeEventListener("mousedown", onResetMouseDown);
        reset.removeEventListener("click", onResetClick);
        close.removeEventListener("mousedown", onResetMouseDown);
        close.removeEventListener("click", onCloseClick);
        grip.removeEventListener("mousedown", onGripMouseDown);
        document.removeEventListener("mousemove", onDragMove);
        document.removeEventListener("mouseup", onDragEnd);
        document.removeEventListener("mousemove", onResizeMove);
        document.removeEventListener("mouseup", onResizeEnd);
        connect.removeEventListener("click", onConnectClick);
        cardConnect.removeEventListener("mousedown", onResetMouseDown);
        cardConnect.removeEventListener("click", onConnectClick);
        input.removeEventListener("keydown", onKeyDown);
        input.removeEventListener("keyup", stop);
        root.removeEventListener("mousedown", stop);
        root.removeEventListener("wheel", onWheel);
        if (root.parentNode) {
            root.parentNode.removeChild(root);
        }
    },
};
